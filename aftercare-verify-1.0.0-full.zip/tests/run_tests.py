"""Authored fixtures + mutation tests, NOT LLM behavior or real platform tests."""
import copy, json, sys, platform, hashlib, os
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'aftercare-verify/scripts'))
from check_report import check, structural, SCHEMA

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
cases=read(ROOT/'tests/cases.json'); checks=[]
def record(category,name,ok,detail=None):checks.append({'category':category,'name':name,'passed':bool(ok),'detail':detail})
def run(c):return check(c['request'],c['proposed_result'],c['synthetic_host'])
for c in cases:
 before=copy.deepcopy(c);out=run(c)
 record('schema_and_authored_examples',str(c['id'])+':'+c['name'],not out['errors'],out)
 record('unknown_duplicate_guard',str(c['id'])+':pending_stays_held',out['hold_external_write'])
 record('read_only',str(c['id'])+':input_not_mutated',c==before)
 # Each case has a deliberately unsupported semantic escalation, not just a string test.
 bad=copy.deepcopy(c);d=bad['proposed_result']['data']
 if c['id'] in (2,6,19,20,22,26):d['case_terminal']=True;d['business_result']='refund_reported'
 elif c['id'] in (14,15,16):d['actual_receipt_confirmed']='yes'
 elif c['id']==17:d['case_terminal']=True;d['business_result']='final_rejection'
 elif c['id']==18:d['case_terminal']=True;d['business_result']='user_withdrawn'
 elif c['id']==24:d['evidence_refs']=['ev-page','ev-missing']
 elif c['id']==25:d['platform_state']='pending';d['evidence_refs']=['ev-page']
 else:d['effect_result']='confirmed_success';d['stage_complete']=True;d['evidence_refs']=['ev-page']
 out=run(bad);record('semantic_mutations',str(c['id'])+':reject_overclaim',bool(out['errors']),out['errors'])

base=cases[1]
def negative(name,fn,category='binding_and_time',start=base):
 c=copy.deepcopy(start);fn(c);out=run(c);record(category,name,bool(out['errors']),out['errors'])
negative('response_call',lambda c:c['proposed_result'].update(call_id='other'))
negative('stale_task',lambda c:c['synthetic_host'].update(current_revision=5))
negative('missing_proposal',lambda c:c['synthetic_host']['proposals'].clear())
negative('payload_changed',lambda c:c['synthetic_host']['proposals']['proposal-1'].update(payload_digest='b'*64))
negative('proposal_target_changed',lambda c:c['synthetic_host']['proposals']['proposal-1']['action'].update(target_item_ref='item-2'))
negative('receipt_task_changed',lambda c:c['synthetic_host']['registry']['receipt']['data'].update(task_id='other'))
negative('wrong_ref_type',lambda c:c['synthetic_host']['registry']['view'].update(kind='Observation'))
negative('wrong_ref_revision',lambda c:c['synthetic_host']['registry']['view'].update(revision=2))
negative('missing_ref',lambda c:c['synthetic_host']['registry'].pop('view'))
negative('forged_runtime_trust',lambda c:c['synthetic_host']['registry']['receipt'].update(trust='untrusted_skill_output'))
negative('inaccessible_artifact',lambda c:c['synthetic_host']['registry']['ledger'].update(accessible=False))
negative('evidence_other_task',lambda c:c['synthetic_host']['evidence']['ev-page'].update(task_id='other'))
negative('account_changed',lambda c:c['synthetic_host']['evidence']['ev-page'].update(account_ref='other'))
negative('case_changed',lambda c:c['synthetic_host']['evidence']['ev-page'].update(case_ref='other'))
negative('expired_evidence',lambda c:c['synthetic_host']['evidence']['ev-page'].update(valid_until='2026-09-27T09:00:00+08:00'))
negative('page_changed',lambda c:c['synthetic_host'].update(page_revision=3))
negative('observation_before_action',lambda c:c['synthetic_host']['evidence']['ev-page'].update(captured_at='2026-09-27T10:00:00+08:00'))
negative('future_evidence',lambda c:c['synthetic_host']['evidence']['ev-page'].update(captured_at='2026-09-28T10:00:00+08:00'))
negative('occluded_incomplete',lambda c:c['synthetic_host']['evidence']['ev-page'].update(complete=False))
negative('not_official',lambda c:c['synthetic_host']['evidence']['ev-page'].update(official=False))
negative('possible_link_not_exact',lambda c:c['synthetic_host']['evidence']['ev-page']['claims']['effect'].update(association='possible'))
negative('missing_stage',lambda c:c['synthetic_host']['target'].update(stage_id=None))
negative('partial_not_complete',lambda c:c['synthetic_host']['evidence']['ev-page']['claims']['effect'].update(all_parts=False))
negative('empty_success_evidence',lambda c:c['proposed_result']['data'].update(evidence_refs=[]))
negative('tool_success_not_business',lambda c:c['synthetic_host']['evidence']['ev-page']['claims'].pop('effect'))
negative('not_attempted_from_missing_receipt',lambda c:(c['request']['inputs'].update(receipt=None),c['proposed_result']['data'].update(effect_result='not_attempted',stage_complete=False)))
negative('issues_in_completed',lambda c:c['proposed_result']['issues'].append({'code':'missing_input','message':'x','retryable':False,'evidence_refs':[]}),'schema')
negative('null_data',lambda c:c['proposed_result'].update(data=None),'schema')
negative('unknown_enum',lambda c:c['proposed_result']['data'].update(platform_state='new_status'),'schema')
negative('partial_wire_enum',lambda c:c['proposed_result']['data'].update(effect_result='partial'),'schema')
negative('understanding_claim_extra_field',lambda c:c['proposed_result']['data'].update(user_understood=True),'schema')
negative('hidden_host_wire_input',lambda c:c['request']['inputs'].update(host={}),'schema')
negative('unknown_host_fail_closed',lambda c:c.update(synthetic_host={}))
# Positive failure and not-attempted avoid an always-reject implementation.
c=copy.deepcopy(base);h=c['synthetic_host'];r=c['proposed_result'];r['data'].update(effect_result='confirmed_failure',stage_complete=False)
h['evidence']['ev-page']['claims']['effect']['result']='confirmed_failure'
record('semantic_positive','explicit_action_rejection',not run(c)['errors'],run(c))
c=copy.deepcopy(c);c['synthetic_host']['other_unresolved_attempts']=True
record('unknown_duplicate_guard','failure_does_not_hide_other_attempt',bool(run(c)['errors']),run(c))
c=copy.deepcopy(cases[0]);h=c['synthetic_host'];r=c['proposed_result'];h['registry']['receipt']['data'].update(dispatch_state='not_sent',tool_state='not_started');h['pending_business_keys']=[];h['registry']['snapshot']['data']['pending_execution_refs']=[];h['registry']['ledger']['data']['events']=[];r['data']['effect_result']='not_attempted'
record('semantic_positive','explicit_not_sent_not_started',not run(c)['errors'],run(c))
# Candidate source binding is deliberately NOT enabled in central v1 examples.
for source in ('user_statement','independent_receipt'):
 c=copy.deepcopy(cases[14]);h=c['synthetic_host'];r=c['proposed_result'];h['receipt_source_binding_enabled']=True
 e=copy.deepcopy(h['evidence']['ev-page']);e.update(source=source,raw_text='合成到账证据');e['claims']={'actual_receipt_confirmed':'yes'};h['evidence']['ev-arrival']=e;r['data']['evidence_refs'].append('ev-arrival');r['data']['actual_receipt_confirmed']='yes'
 record('candidate_only',source,not run(c)['errors'],run(c))
# No side effects on repeated verification; this is not persistent exactly-once execution.
c=copy.deepcopy(base);a=run(c);b=run(c)
record('unknown_duplicate_guard','repeat_same_input_same_diagnostic',a==b and c==base)
# Candidate structural tests.
schema=read(ROOT/'candidate/verification-assessment.schema.json');v=Draft202012Validator(schema,format_checker=FormatChecker());Draft202012Validator.check_schema(schema)
record('candidate_schema','partial_valid',not list(v.iter_errors(read(ROOT/'candidate/positive-partial.json'))))
record('candidate_schema','bad_enum_rejected',bool(list(v.iter_errors(read(ROOT/'candidate/negative-invalid-enum.json')))))
record('candidate_schema','unknown_cannot_release_guard',bool(list(v.iter_errors(read(ROOT/'candidate/negative-release-unknown.json')))))
handoff_schema=read(ROOT/'examples/handoff.schema.json')
for filename,definition in [('recover-request','aftercare-recoverRequest'),('resume-request','aftercare-resumeRequest'),('upstream-interact-request','aftercare-interactRequest'),('upstream-interact-result','aftercare-interactResult')]:
 validator=Draft202012Validator({**handoff_schema,'$ref':'#/$defs/'+definition},format_checker=FormatChecker())
 record('handoff_schema',filename,not list(validator.iter_errors(read(ROOT/('examples/'+filename+'.json')))))
# Verify extracted definitions against actual authority (read-only, local path).
provenance=read(ROOT/'aftercare-verify/references/provenance.json');src=Path(os.environ.get('AFTERCARE_CONTRACT_SCHEMA', provenance['source']))
if src.exists():
 raw=src.read_bytes();original=json.loads(raw.decode('utf-8-sig'))
 record('schema','authority_hash',hashlib.sha256(raw).hexdigest()==provenance['sha256'])
 record('schema','all_definitions_unmodified',all(original['$defs'][k]==v for k,v in SCHEMA['$defs'].items()))
else:record('integration','authority_available',False,'Not available; not passed')
# Call the previous deliverable's REAL Python stub; do not pretend it returns ExecutionReceipt.
up=Path(os.environ.get('AFTERCARE_INTERACT_OUTPUTS', 'external-source/aftercare-interact-outputs'))
if up.exists():
 sys.path[:0]=[str(up/'aftercare-interact/scripts'),str(up/'tests')]
 from executor_stub import ExecutorStub, binding
 from validate_plan import validate
 f=read(up/'examples/pending-authorization.json');gate=ExecutorStub()
 record('integration_stub','upstream_plan_valid',not validate(f['request'],f['result'],f['host']))
 no=gate.check_and_record(f['request'],f['result'],f['host'])
 record('integration_stub','no_authorization_no_send',not no['sent'])
 consent={'source':'synthetic_user_event','digest':binding(f['request'],f['result'],f['host']),'consumed':False}
 sent=gate.check_and_record(f['request'],f['result'],f['host'],consent)
 record('integration_stub','stub_sent_unknown',sent.get('sent') and sent.get('business_result')=='unknown',sent)
 record('integration_stub','stub_is_not_execution_receipt',bool(structural(sent,'ExecutionReceipt')))
 f2=copy.deepcopy(f);f2['result']['data']['actions'][0]['proposal_id']='new-proposal'
 again=gate.check_and_record(f2['request'],f2['result'],f2['host'],consent)
 record('integration_stub','new_proposal_same_effect_rejected',not again['sent'],again)
 # explicit synthetic harness mapping from real upstream Action; still no real Receipt.
 c=copy.deepcopy(cases[0]);q=c['request'];h=c['synthetic_host'];a=f['result']['data']['actions'][0]
 h['proposals']={a['proposal_id']:{'action':a,'payload_digest':'a'*64}}
 h['target']['proposal_id']=a['proposal_id'];h['target_item_ref']=a['target_item_ref'];h['registry']['snapshot']['data']['target_item_ref']=a['target_item_ref'];h['registry']['receipt']['data'].update(proposal_id=a['proposal_id'],target_item_ref=a['target_item_ref'],tool_state='unknown',dispatch_state='unknown')
 out=run(c);record('integration_stub','explicit_synthetic_receipt_mapping_holds_unknown',not out['errors'] and out['hold_external_write'],out)
else:record('integration_stub','upstream_available',False,'Missing; not skipped as pass')
summary={'scope':'offline authored fixtures, semantic rejection guards, and actual imported in-memory upstream stub; no LLM/browser/real aftercare run','environment':{'python':platform.python_version(),'platform':platform.platform()},'passed':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks,'not_run':['independent model forward tests','production platform adapter','real ExecutionReceipt service and persistent resolver','recover/resume downstream implementation','test mall with independent backend truth','real platform and bank receipt','concurrency/crash recovery','user comprehension study']}
(ROOT/'tests/results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':summary['passed'],'total':summary['total'],'failures':[x for x in checks if not x['passed']]},ensure_ascii=False,indent=2))
raise SystemExit(0 if summary['passed']==summary['total'] else 1)
